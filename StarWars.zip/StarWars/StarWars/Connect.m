//
//  Connect.m
//  StarWars
//
//  Created by itsector on 20/09/2019.
//  Copyright © 2019 itsector. All rights reserved.
//

#import "Connect.h"
#import "AFNetworking.h"

@implementation Connect

+ (void)getInformationFromJson:(NSString *)url success:(void (^)(NSDictionary * _Nonnull))resp {
    AFHTTPSessionManager *manager = [AFHTTPSessionManager manager];
    [manager GET: url parameters:nil progress:nil success:^(NSURLSessionTask *task, id responseObject) {
        
        
        //passa do Json para um dicionario
        NSMutableDictionary *json = responseObject;
        
        //retorna o dicionario para o viewController
        resp(json);
        
    } failure:^(NSURLSessionTask *operation, NSError *error) {
        NSLog(@"Error: %@", error);
    }];
    
}

@end
