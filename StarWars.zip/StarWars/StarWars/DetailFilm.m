//
//  DetailFilm.m
//  StarWars
//
//  Created by itsector on 20/09/2019.
//  Copyright © 2019 itsector. All rights reserved.
//

#import "DetailFilm.h"

@implementation DetailFilm

+(DetailFilm *) filmFromJson: (NSArray *)json {
    
    DetailFilm *film = [[DetailFilm alloc] init];
    NSArray *arrayDic = json;
    NSLog(@"AQUI");
    film.title = [arrayDic valueForKey:@"title"];
    film.director = [arrayDic valueForKey:@"director"];
    film.producer = [arrayDic valueForKey:@"producer"];
    film.opening_crawl = [arrayDic valueForKey:@"opening_crawl"];
    film.characters = [arrayDic valueForKey:@"characters"];
    film.planets = [arrayDic valueForKey:@"planets"];
    film.vehicles = [arrayDic valueForKey:@"vehicles"];
    return film;
}

@end
