//
//  FilmsListTableViewController.m
//  StarWars
//
//  Created by itsector on 20/09/2019.
//  Copyright © 2019 itsector. All rights reserved.
//

#import "FilmsListTableViewController.h"
#import "FilmTableViewCell.h"
#import "ConnectManager.h"
#import "AFNetworking.h"
#import "UIImageView+AFNetworking.h"
#import "Results.h"
#import "DetailsFilmViewController.h"

@interface FilmsListTableViewController ()
@property(nonatomic, assign) int currentPage;
@end

@implementation FilmsListTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.currentPage = 1;
    
    [ConnectManager getListFilms: ^(NSDictionary * _Nonnull list) {
        NSDictionary *films = list;
        
        self.listOfFilms = [AllFilms listOfAllFilmsFromJson: films];
        NSString *nameBeer = [self.listOfFilms valueForKey:@"nameOfFilm"];
        
        NSLog(@"names: %@", nameBeer);
        [[self filmTableView] reloadData];
    }];
    
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.listOfFilms.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    FilmTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"FilmCell" forIndexPath:indexPath];
    
    long row = [indexPath row];
    cell.nameFilmLabel.text = self.listOfFilms[row].nameOfFilm;
    return cell;
    
    return cell;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

-(void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [self performSegueWithIdentifier:@"DetailsFilmSegue" sender:self];
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"DetailsFilmSegue"]) {
        DetailsFilmViewController *destViewController = segue.destinationViewController;
        NSIndexPath *indexPath = [self.filmTableView  indexPathForSelectedRow];
        destViewController.detailsOfFilm = [self.listOfFilms objectAtIndex:indexPath.row].episodeID;
    }
}


@end
