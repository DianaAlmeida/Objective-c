//
//  SpecificDetailsTableViewCell.m
//  StarWars
//
//  Created by itsector on 23/09/2019.
//  Copyright © 2019 itsector. All rights reserved.
//

#import "SpecificDetailsTableViewCell.h"

@implementation SpecificDetailsTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
