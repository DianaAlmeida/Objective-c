//
//  AllFilms.m
//  StarWars
//
//  Created by itsector on 20/09/2019.
//  Copyright © 2019 itsector. All rights reserved.
//

#import "AllFilms.h"

@implementation AllFilms

+(NSMutableArray *) listOfAllFilmsFromJson: (NSDictionary *) json {
    NSMutableArray <AllFilms*> *listOfFilms = [NSMutableArray new];
    NSMutableArray *nameOfFilmFINAL= [[json valueForKey:@"results"] valueForKey:@"title"];
    NSMutableArray *episodeIDFINAL = [[json valueForKey:@"results"] valueForKey:@"episode_id"];

    NSLog(@"%@", nameOfFilmFINAL);
    NSLog(@"%@", episodeIDFINAL);
    
    for (NSDictionary *eachFilm in [json valueForKey:@"results"]) {
        NSString *nameOfFilm = [eachFilm valueForKey:@"title"];
        NSNumber *episodeID = [eachFilm valueForKey:@"episode_id"];
        
        AllFilms *theFilm = [AllFilms new];
        theFilm.nameOfFilm = nameOfFilm;
        theFilm.episodeID = episodeID;
        
        [listOfFilms addObject:theFilm];
    }
    
    return listOfFilms;
}

@end
