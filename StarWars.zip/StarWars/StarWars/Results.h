//
//  Results.h
//  StarWars
//
//  Created by itsector on 20/09/2019.
//  Copyright © 2019 itsector. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Results : NSObject
+(NSMutableArray *) listOFResultsFromJson: (NSDictionary *) json;
@property(strong, nonatomic) NSString *results;
@end

NS_ASSUME_NONNULL_END
