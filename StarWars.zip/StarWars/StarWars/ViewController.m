//
//  ViewController.m
//  StarWars
//
//  Created by itsector on 19/09/2019.
//  Copyright © 2019 itsector. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
