//
//  FilmTableViewCell.h
//  StarWars
//
//  Created by itsector on 20/09/2019.
//  Copyright © 2019 itsector. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface FilmTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *nameFilmLabel;

@end

NS_ASSUME_NONNULL_END
