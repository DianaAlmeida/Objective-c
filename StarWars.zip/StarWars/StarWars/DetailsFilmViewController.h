//
//  DetailsFilmViewController.h
//  StarWars
//
//  Created by itsector on 20/09/2019.
//  Copyright © 2019 itsector. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DetailFilm.h"
#import "AllFilms.h"
#import "VehicleDetails.h"

NS_ASSUME_NONNULL_BEGIN

@interface DetailsFilmViewController : UIViewController
@property (weak, nonatomic) IBOutlet UINavigationItem *titleFilmLabel;
@property (weak, nonatomic) IBOutlet UILabel *directorLabel;
@property (weak, nonatomic) IBOutlet UILabel *producerLabel;
@property (weak, nonatomic) IBOutlet UILabel *releasedDataLabel;
@property (weak, nonatomic) IBOutlet UILabel *opennedLabel;
@property(strong, nonatomic) DetailFilm *detailsOfFilm;
@property(strong, nonatomic) AllFilms *episodeID;
@property(strong, nonatomic) NSDictionary *objectFilm;
@property(strong, nonatomic)VehicleDetails *vehicles;



@end

NS_ASSUME_NONNULL_END
