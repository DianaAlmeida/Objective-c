//
//  DetailFilm.h
//  StarWars
//
//  Created by itsector on 20/09/2019.
//  Copyright © 2019 itsector. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface DetailFilm : NSObject

@property(nonatomic, strong) NSString *title;
@property(nonatomic, strong) NSString *director;
@property(nonatomic, strong) NSString *producer;
@property(nonatomic,strong) NSString *opening_crawl;
@property(nonatomic, strong) NSString *characters;
@property(nonatomic, strong) NSString *planets;
@property(nonatomic, strong) NSString *vehicles;
//@property(strong, nonatomic) DetailFilm *specificOfFilm;
+(DetailFilm *) filmFromJson: (NSArray *)json;

@end

NS_ASSUME_NONNULL_END
