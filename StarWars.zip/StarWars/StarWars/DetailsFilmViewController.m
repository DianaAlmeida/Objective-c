//
//  DetailsFilmViewController.m
//  StarWars
//
//  Created by itsector on 20/09/2019.
//  Copyright © 2019 itsector. All rights reserved.
//

#import "DetailsFilmViewController.h"
#import "ConnectManager.h"
#import "DetailFilm.h"
#import "SpecificDetailTableViewController.h"


@interface DetailsFilmViewController ()

@end

@implementation DetailsFilmViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [ConnectManager getFilmDetail: self.detailsOfFilm with:^(DetailFilm * _Nonnull film) {
        
      //  NSDictionary *objectFilm = film;
        self.objectFilm = film;
        self.titleFilmLabel.title = [self.objectFilm valueForKey:@"title"];
        self.directorLabel.text = [self.objectFilm valueForKey:@"director"];
        self.producerLabel.text = [self.objectFilm valueForKey:@"producer"];
     //   self.releasedDataLabel.text = [objectFilm valueForKey:@"release_date"];
        self.opennedLabel.text = [self.objectFilm valueForKey:@"opening_crawl"];
        
    }];
}



- (IBAction)planetsButton:(id)sender {
}
- (IBAction)charactersButton:(id)sender {
}
- (IBAction)vehiclesButton:(id)sender {
}

#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation

-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    if ([segue.identifier isEqualToString:@"vehiclesSegue"]) {
        SpecificDetailTableViewController *destViewController = segue.destinationViewController;
        //NSIndexPath *index= sender;
        destViewController.listOfVehicles = [self.objectFilm valueForKey:@"vehicles"];
    }
    
    if ([segue.identifier isEqualToString:@"charactersSegue"]) {
        SpecificDetailTableViewController *destViewController = segue.destinationViewController;
        NSIndexPath *index= sender;
        //destViewController.listOfVehicles = [self.detailsOfFilm[index] valueForKey:@"characters"];
    }
    
    if ([segue.identifier isEqualToString:@"planetsSegue"]) {
        SpecificDetailTableViewController *destViewController = segue.destinationViewController;
        //NSIndexPath *index= sender;
        destViewController.listOfVehicles = [self.detailsOfFilm valueForKey:@"planets"];
    }
}
@end
