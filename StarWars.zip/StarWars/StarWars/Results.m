//
//  Results.m
//  StarWars
//
//  Created by itsector on 20/09/2019.
//  Copyright © 2019 itsector. All rights reserved.
//

#import "Results.h"
#

@implementation Results
+(NSMutableArray *) listOFResultsFromJson: (NSDictionary *) json {
    NSMutableArray <Results*> *listOfResults = [NSMutableArray new];
    
    NSMutableArray *arrayWithResults = [[NSMutableArray alloc] init];
    NSArray *arrayDic = json;
    NSLog(@"AQUI RESULTS");
    arrayWithResults = [[arrayDic valueForKey:@"results"] valueForKey:@"title"];
    [listOfResults addObject:arrayWithResults];
    return listOfResults;
    
}
@end
