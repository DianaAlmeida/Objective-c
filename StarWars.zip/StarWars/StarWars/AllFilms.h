//
//  AllFilms.h
//  StarWars
//
//  Created by itsector on 20/09/2019.
//  Copyright © 2019 itsector. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface AllFilms : NSObject
@property(strong, nonatomic) NSString *nameOfFilm;
@property(strong, nonatomic) NSString *results;
@property(strong, nonatomic) NSNumber *episodeID;
+(NSMutableArray *) listOfAllFilmsFromJson: (NSDictionary *) json;
//+(NSMutableArray *) listOFResultsFromJson: (NSDictionary *) json;
@end

NS_ASSUME_NONNULL_END
