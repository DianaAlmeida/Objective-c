//
//  ConnectManager.m
//  StarWars
//
//  Created by itsector on 20/09/2019.
//  Copyright © 2019 itsector. All rights reserved.
//

#import "ConnectManager.h"
#import "DetailFilm.h"
#import "Connect.h"
#import "VehicleDetails.h"

@implementation ConnectManager

+(void) getListFilms: (void (^)(NSDictionary * _Nonnull))films {
    
 //   NSString *inStr = [NSString stringWithFormat: @"%ld", (long)currentPage];
    NSString *myListUrl;
    
  //  myListUrl = [@"https://swapi.co/api/films/={1}" stringByReplacingOccurrencesOfString:@"{1}" withString: inStr];
    myListUrl = @"https://swapi.co/api/films/";
    
    NSLog(@"url: %@", myListUrl);
    
    [Connect getInformationFromJson: myListUrl success:^(NSDictionary * _Nonnull response) {
        
        NSLog(@"AQUI");
        NSDictionary *filmInJson = response;
        NSLog(@"json: %@", filmInJson);
        films(filmInJson);
    }];
    
}

+(void)getFilmDetail: (NSString *) filmUrl with: (void(^)(DetailFilm *film))film {
    
    NSString *myUrl = [NSString stringWithFormat:@"https://swapi.co/api/films/%@", filmUrl ];
    
    [Connect getInformationFromJson:myUrl success:^(NSDictionary *_Nonnull response) {
        
        NSDictionary *objectFilm = response;
        NSLog(@"GET FILM DETAIL2");
       DetailFilm *listOfFilm = [DetailFilm filmFromJson:objectFilm];
        NSLog(@"Details OF FILM!");
        film(listOfFilm);
        
        
    }];
}

+(void) getVehiclesDetail: (NSString *) vehicleUrl with:(void(^)(VehicleDetails *vehicle))vehicle {
    //NSString *myListUrl = @"https://swapi.co/api/vehicles/35/";
    [Connect getInformationFromJson:vehicleUrl success:^(NSDictionary * _Nonnull response)  {
        
        NSDictionary *objectVehicles = response;
        NSLog(@"get VEHICLES");
        //DetailFilm *listOfVehicles = [DetailFilm filmFromJson: objectVehicles];
        VehicleDetails *listOfVehicle = [VehicleDetails vehicleFromJson:objectVehicles];
        NSLog(@"json: %@", listOfVehicle.nameOfVehicle);
        vehicle(listOfVehicle.nameOfVehicle);
    }];
    
}

@end
