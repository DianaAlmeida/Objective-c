//
//  VehicleDetails.h
//  StarWars
//
//  Created by itsector on 23/09/2019.
//  Copyright © 2019 itsector. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface VehicleDetails : NSObject
@property(nonatomic, strong) NSString *vehicles;
@property(nonatomic, strong) NSString *nameOfVehicle;
+(VehicleDetails *) vehicleFromJson: (NSDictionary *) json;
@end

NS_ASSUME_NONNULL_END
