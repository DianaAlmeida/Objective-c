//
//  ConnectManager.h
//  StarWars
//
//  Created by itsector on 20/09/2019.
//  Copyright © 2019 itsector. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DetailFilm.h"
#import "VehicleDetails.h"
NS_ASSUME_NONNULL_BEGIN

@interface ConnectManager : NSObject
+(void) getListFilms: (void (^)(NSDictionary * _Nonnull))films;
+(void)getFilmDetail: (NSString *) filmUrl with: (void(^)(DetailFilm *film))film;
+(void) getVehiclesDetail: (NSString *) vehicleUrl with:(void(^)(VehicleDetails *vehicle))vehicle;
@property (strong, nonatomic) DetailFilm *detailsOfFilm;

@end

NS_ASSUME_NONNULL_END
