//
//  VehicleDetails.m
//  StarWars
//
//  Created by itsector on 23/09/2019.
//  Copyright © 2019 itsector. All rights reserved.
//

#import "VehicleDetails.h"

@implementation VehicleDetails
+(VehicleDetails *) vehicleFromJson: (NSDictionary *) json {
    
    VehicleDetails *vehicle = [[VehicleDetails alloc] init];
    NSArray *arrayVehicle = json;
    vehicle.nameOfVehicle = [arrayVehicle valueForKey:@"name"];
    NSLog(@"names: %@", vehicle.nameOfVehicle);
    return vehicle;
}
@end
