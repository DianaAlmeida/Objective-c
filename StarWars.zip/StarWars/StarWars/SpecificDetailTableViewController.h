//
//  SpecificDetailTableViewController.h
//  StarWars
//
//  Created by itsector on 23/09/2019.
//  Copyright © 2019 itsector. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DetailFilm.h"
#import "VehicleDetails.h"

NS_ASSUME_NONNULL_BEGIN

@interface SpecificDetailTableViewController : UITableViewController
@property(strong, nonatomic) DetailFilm *specificOfFilm;
@property(strong, nonatomic) NSMutableArray <VehicleDetails*> *listOfVehicles;
@property(strong, nonatomic) NSMutableArray <VehicleDetails*> *listOfNamesVehicles;
@end

NS_ASSUME_NONNULL_END
