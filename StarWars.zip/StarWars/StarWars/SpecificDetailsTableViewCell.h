//
//  SpecificDetailsTableViewCell.h
//  StarWars
//
//  Created by itsector on 23/09/2019.
//  Copyright © 2019 itsector. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SpecificDetailsTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *vehicleNameLabel;
@end

NS_ASSUME_NONNULL_END
