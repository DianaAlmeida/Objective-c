//
//  Connect.h
//  StarWars
//
//  Created by itsector on 20/09/2019.
//  Copyright © 2019 itsector. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Connect : NSObject
+(void) getInformationFromJson: (NSString *) url success: (void(^) (NSDictionary * _Nonnull)) resp;
@end

NS_ASSUME_NONNULL_END
