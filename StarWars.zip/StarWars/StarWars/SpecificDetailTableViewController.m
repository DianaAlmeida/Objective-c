//
//  SpecificDetailTableViewController.m
//  StarWars
//
//  Created by itsector on 23/09/2019.
//  Copyright © 2019 itsector. All rights reserved.
//

#import "SpecificDetailTableViewController.h"
#import "SpecificDetailsTableViewCell.h"
#import "ConnectManager.h"
#import "DetailFilm.h"
#import "AFNetworking.h"
#import "UIImageView+AFNetworking.h"

@interface SpecificDetailTableViewController ()

@end

@implementation SpecificDetailTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSLog(@"blabla: %@", self.listOfVehicles);
    
   NSInteger *numberOfVehicles = self.listOfVehicles.count;
    
    for (int i = 0; i < numberOfVehicles; i++) {
        
        [ConnectManager getVehiclesDetail: self.listOfVehicles[i] with:^(VehicleDetails * _Nonnull vehicle) {
            NSDictionary *vehicles = vehicle;
            
           // self.listOfVehicles = [VehicleDetails vehicleFromJson:vehicles];
//            NSString *nameVehicle = [self.listOfNamesVehicles valueForKey:@"name"];
            self.listOfNamesVehicles = vehicles;
           NSLog(@"namesFINAL: %@", self.listOfNamesVehicles);
        }];
         [[self tableView] reloadData];
        
    }
    
    

}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.listOfVehicles.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    SpecificDetailsTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"specificCell" forIndexPath:indexPath];
    
    long row = [indexPath row];
    cell.vehicleNameLabel.text = self.listOfNamesVehicles[row].nameOfVehicle;
    return cell;
}


/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
